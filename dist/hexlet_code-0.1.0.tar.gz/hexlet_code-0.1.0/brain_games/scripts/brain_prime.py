from brain_games.structure import structure
from brain_games.games import prime


def main():
    structure(prime)


if __name__ == '__main__':
    main()
