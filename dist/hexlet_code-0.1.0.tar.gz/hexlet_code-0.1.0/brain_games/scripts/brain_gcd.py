from brain_games.structure import structure
from brain_games.games import gcd


def main():
    structure(gcd)


if __name__ == '__main__':
    main()
