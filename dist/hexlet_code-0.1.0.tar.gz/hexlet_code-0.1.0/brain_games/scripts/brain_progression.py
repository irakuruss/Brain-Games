from brain_games.structure import structure
from brain_games.games import progression


def main():
    structure(progression)


if __name__ == '__main__':
    main()
